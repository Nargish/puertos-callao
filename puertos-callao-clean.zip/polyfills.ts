import "react-native-get-random-values";
import "react-native-url-polyfill/auto";